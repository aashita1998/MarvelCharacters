package com.example.acer.assesmenttest;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    Context context;
    ArrayList<ComicPojo> list;
    public MyAdapter(FragmentActivity listener, ArrayList<ComicPojo> arrayList) {
    this.context=listener;
    this.list=arrayList;
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(context).inflate(R.layout.details,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {
        Picasso.with(context).load(list.get(position).getDeals()).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView imageView;
        public ViewHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.im);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
int pos=getAdapterPosition();
            Intent i=new Intent(context,Main2Activity.class);
            i.putExtra("deal",list.get(pos).getDeals());
            i.putExtra("name",list.get(pos).getNames1());
            i.putExtra("description",list.get(pos).getDecscription());
            i.putExtra("modified",list.get(pos).getModifiedDAta());
            context.startActivity(i);
        }
    }
}
