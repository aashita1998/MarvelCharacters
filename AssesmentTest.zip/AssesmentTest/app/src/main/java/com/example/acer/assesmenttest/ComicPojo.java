package com.example.acer.assesmenttest;

import org.json.JSONObject;

class ComicPojo {
public String deals;
public  String names1;
public  String decscription;
public  String modifiedDAta;

    public String getDeals() {
        return deals;
    }

    public void setDeals(String deals) {
        this.deals = deals;
    }

    public String getNames1() {
        return names1;
    }

    public void setNames1(String names1) {
        this.names1 = names1;
    }

    public String getDecscription() {
        return decscription;
    }

    public void setDecscription(String decscription) {
        this.decscription = decscription;
    }

    public String getModifiedDAta() {
        return modifiedDAta;
    }

    public void setModifiedDAta(String modifiedDAta) {
        this.modifiedDAta = modifiedDAta;
    }

    public ComicPojo(String deals, String names1, String decscription, String modifiedDAta) {
        this.deals = deals;
        this.names1 = names1;
        this.decscription = decscription;
        this.modifiedDAta = modifiedDAta;
    }
}
