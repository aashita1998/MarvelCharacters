package com.example.acer.assesmenttest;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment extends Fragment {
RecyclerView recyclerView;
RequestQueue requestQueue;
ArrayList<ComicPojo> list;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_blank2, container, false);
        recyclerView=view.findViewById(R.id.rec);
        requestQueue= Volley.newRequestQueue(getActivity());
        list=new ArrayList<>();
        data();
    return  view;

    }


public  void  data(){
        String url="https://gateway.marvel.com/v1/public/characters?ts=1&apikey=9cc1a6a0723c43b6347867f74090e07c&hash=ee3212adb6ff845ae493ad08b592cdc0";
    StringRequest request=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            try {
                String paths;
                String ext;
                String deal = null;
                String names=null;
                String dec;
                String modifiedDate;
                JSONObject object1 = new JSONObject(response);
                JSONObject data = object1.getJSONObject("data");
                JSONArray result = data.getJSONArray("results");
                for (int i = 0; i < result.length(); i++) {
                    JSONObject object2 = result.getJSONObject(i);
                    names=object2.getString("name");
                    dec=object2.getString("description");
                    modifiedDate=object2.getString("modified");
                    JSONObject thumbnails = object2.getJSONObject("thumbnail");
                    paths =  thumbnails.getString("path");
                    ext = thumbnails.getString("extension");
                    deal=paths.concat(".").concat(ext);
                    ComicPojo comicPojo = new ComicPojo(deal,names,dec,modifiedDate);
                    list.add(comicPojo);
                                    }
                MyAdapter adapter=new MyAdapter(getActivity(),list);
                recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),2));
                recyclerView.setAdapter(adapter);
               // Toast.makeText(getActivity(), ""+deal, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

        }
    });
    requestQueue.add(request);
}
}
