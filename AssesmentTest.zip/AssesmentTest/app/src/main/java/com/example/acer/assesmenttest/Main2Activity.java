package com.example.acer.assesmenttest;

import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class Main2Activity extends AppCompatActivity {
@InjectView(R.id.im)
    ImageView imageView;
@InjectView(R.id.name_tv)
    TextView textView1;
    @InjectView(R.id.dec_tv)
    TextView textView2;
    @InjectView(R.id.modified_tv)
    TextView textView3;
RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ButterKnife.inject(this);
        requestQueue= Volley.newRequestQueue(this);
        String deal=getIntent().getStringExtra("deal");
        String name=getIntent().getStringExtra("name");
        String des=getIntent().getStringExtra("description");
        String modify=getIntent().getStringExtra("modified");
        Picasso.with(this).load(deal).into(imageView);
         textView1.setText("Name:"+name);
         textView2.setText("Description:"+des);
         textView3.setText("Modified Date:"+modify);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId()==android.R.id.home){
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }
}
